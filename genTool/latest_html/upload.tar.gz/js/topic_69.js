$( function() {

$('#list315').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/1680861338881962_2.jpg');
	$('#topic69 span.listtxt').html('高中时听到艾薇儿的歌声，直接被震撼住了，极具活力和穿透力的嗓音让人听了很兴奋。');
	});
$('#list315').click(function() {
	$('#musicPlayer h3').html('Let Go');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2073769,2073770,2073771,2073772,2073773,2073774,2073775,2073776,2073777,2073778,2073779,2073780,2073781,1769587874,1769589412,1769589413,1769589414,1769589415,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list315').css('color', '#CC0052');
	});

$('#list316').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/1680871343891504_2.jpg');
	$('#topic69 span.listtxt').html('专辑的中文翻译是《酷到骨子里》，你听了就懂了，超有个性，超好听。');
	});
$('#list316').click(function() {
	$('#musicPlayer h3').html('Under My Skin');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2073785,2073786,2073787,2073788,2073789,2073790,2073791,2073792,2073793,2073794,2073795,2073796,2073797,2073798,1769227812,1769227813,1769227814,1769227815,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list316').css('color', '#CC0052');
	});
$('#list317').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/1680891341353693_2.jpg');
	$('#topic69 span.listtxt').html('最火的算是Girlfriend了，“Hey Hey You You，I don\'t like your girlfriend，No way No way，I think you need a new one，Hey Hey You You，I could be your girlfriend”， 歌词太霸气了！');
	});
$('#list317').click(function() {
	$('#musicPlayer h3').html('The Best Damn Thing');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2073834,2073835,2073836,2073837,2073838,2073839,2073840,2073841,2073842,2073843,2073844,2073845,1769487383,1769178705,1769487264,1769491759,1770688335,1769593408,1769593409,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list317').css('color', '#CC0052');
	});
$('#list318').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/3457081338881997_2.jpg');
	$('#topic69 span.listtxt').html('live的演唱听上去更好听了，尤其是当没有那么多的电音的时候~~');
	});
$('#list318').click(function() {
	$('#musicPlayer h3').html('Control Room Live');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769102067,1769102068,1769102069,1769102070,1769102071,1769102072,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list318').css('color', '#CC0052');
	});
$('#list319').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/4107141343891513_2.jpg');
	$('#topic69 span.listtxt').html('多伦多演唱会，很棒~');
	});
$('#list319').click(function() {
	$('#musicPlayer h3').html('The Best Damn Tour');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769863673,1769863674,1769863675,1769863676,1769863677,1769863678,1769863679,1769863680,1769863681,1769863682,1769863683,1769863684,1769863685,1769863686,1769863687,1769863688,1769863689,1769863690,1769863691,1769863692,1769863693,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list319').css('color', '#CC0052');
	});
$('#list320').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/album/img52/23352/4148411338881991_2.jpg');
	$('#topic69 span.listtxt').html('各种经典，各种好听！');
	});
$('#list320').click(function() {
	$('#musicPlayer h3').html('Essential Mixes');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769908796,1769908797,1769908798,1769908799,1769908800,1769908801,1769908802,1769908803,1769908804,1769908805,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list320').css('color', '#CC0052');
	});
$('#list321').mouseover(function() {
	$('#topic69 img').attr('src', 'http://img.xiami.com/images/artistlogo/76/13288645567176_2.jpg');
	$('#topic69 span.listtxt').html('一些其他不错的歌~');
	});
$('#list321').click(function() {
	$('#musicPlayer h3').html('Others');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2073817,2901708,1769487263,1769491741,1770189753,1769532305,1769516727,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic69 li').css('color', '#000000');
	$('#list321').css('color', '#CC0052');
	});
}
)
;
