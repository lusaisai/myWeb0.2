delete from stg_f_topic_w;
insert into stg_f_topic_w
(
  topic_id
, topic_type_id
, topic_name
, topic_tags
, topic_recom_flag
)
values
(
1,
1,
'a',
'b',
'c'
)
;
